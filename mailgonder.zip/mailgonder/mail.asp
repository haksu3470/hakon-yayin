<%
Dim objCDONTS                 ' Email object
Dim webmail, webuser, webmsg, websubj, webto

webmail = request("email")
if webmail = "" then webmail = "admin@turxserver.com"

webuser = request("name")
if webuser = "" then webuser = "Web User"


webmsg = "Sent by turxserver.com" & chr(13)
webmsg = webmsg & "-*-*-*-*-*->  " & date & " <-> " & time & "  <-*-*-*-*-*-" & chr(13) & chr(13)

For Each x In Request.Form
webmsg = webmsg & x & " = " & Request.Form(x) & chr(13)
Next

webmsg = webmsg & chr(13) & chr(13)
webmsg = webmsg & "IP  = " & request.servervariables("remote_addr") & chr(13)
webmsg = webmsg & "URL = " & request.servervariables("http_referer")

	Set objCDONTS = Server.CreateObject("CDONTS.NewMail")
	objCDONTS.From    = webuser & " <" & webmail & ">"
	objCDONTS.To      = "admin@turxserver.com"
	objCDONTS.Subject = "sirtmac web"
	objCDONTS.Body    = webmsg
	objCDONTS.Send
	Set objCDONTS = Nothing

%>
<HTML>
<HEAD>
<TITLE></TITLE>
<STYLE><!--  
a:hover{color:#66CCFF}               
a{cursor:arrow}
a{text-decoration:none;}
//--></STYLE>
<meta http-equiv="Content-Type" content="text/html; charset=x-mac-turkish"></HEAD>
<BODY bgcolor="#FFFFFF" text="#000000" topmargin="1" leftmargin="1" marginwidth="0" marginheight="0" alink="white" vlink="white" link="#FF0000">
<div align="center">
  <p><strong>Mailiniz Ba�ar�yla G�nderilmistir. </strong></p>
  <p><strong>[<a href="index.htm">Anasayfa</a>]</strong></p>
  <p><strong>En K�sa S�rede Mailinize D�n�� Yap�lacakt�r.</strong></p>
</div>
</BODY>
</HTML>

